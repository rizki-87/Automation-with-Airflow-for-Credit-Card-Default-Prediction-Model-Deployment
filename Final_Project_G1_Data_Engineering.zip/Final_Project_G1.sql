--membuat table segment
CREATE TABLE table_fpg1

(
	checking_status varchar,
	duration float,
	credit_history varchar,
	purpose varchar,
	credit_amount float,
	savings_status varchar,
	employment varchar,
	installment_commitment float,
	personal_status varchar,
	other_parties  varchar,
	residence_since  float,
	property_magnitude  varchar,
	age  float,
	other_payment_plans varchar,
    housing  varchar,
    existing_credits  float,
    job  varchar,
    num_dependents float,
    own_telephone  varchar,
    foreign_worker varchar,
    class varchar
);

copy table_fpg1(checking_status, duration, credit_history, purpose, credit_amount, savings_status, employment, installment_commitment, personal_status, other_parties, residence_since, property_magnitude, age, other_payment_plans, housing, existing_credits, job, num_dependents, own_telephone, foreign_worker, class)
FROM 'D:\FINAL PROJECT\credit_customers.csv' 
DELIMITER ',' 
CSV HEADER;

SELECT * FROM table_fpg1;
	